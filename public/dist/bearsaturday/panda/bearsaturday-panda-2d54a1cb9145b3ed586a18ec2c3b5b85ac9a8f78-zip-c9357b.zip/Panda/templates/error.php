<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   
 * @author    Akihito Koriyama <koriyama@bear-project.net>
 * @copyright 2011 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id:$
 * @link      http://www.bear-project.net/
 */

/**
 * BEAR 
 *
 * @category  BEAR
 * @package   
 * @author    Akihito Koriyama <koriyama@bear-project.net>
 * @copyright 2011 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   Release: @package_version@
 * @link      http://www.bear-project.net/
 */
